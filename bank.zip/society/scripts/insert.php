<?php

    session_start();
    include("../../connection.php");

    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $aadhar = $_POST['aadhar'];
    $loantype = $_POST['loantype'];
    $loanamount = $_POST['loanamount'];
    $loanduration = $_POST['loanduration'];
    $garanter = $_POST['loangaranter'];
    $address = $_POST['address'];
    $loanprovider = $_POST['bank_id'];

    if(empty($name)){
        $_SESSION['message_post'] = "Insert Defaulter Name";
        header("location:../Addcustomer.php");
    }
    else if(empty($email)){
        $_SESSION['message_post'] = "Insert Defaulter Email id";
        header("location:../Addcustomer.php");
    }
    else if(empty($contact)){
        $_SESSION['message_post'] = "Insert Defaulter Contact e.g Mobile Number";
        header("location:../Addcustomer.php");
    }
    else if(empty($aadhar)){
        $_SESSION['message_post'] = "Insert Defaulter Aadhar Card Number";
        header("location:../Addcustomer.php");
    }
    else if(empty($loantype)){
        $_SESSION['message_post'] = "Insert Defaulter Loan type e.g home loan , house loan, cc loan etc";
        header("location:../Addcustomer.php");
    }
    else if(empty($loanamount)){
        $_SESSION['message_post'] = "Insert Defaulters Loan Amount in Numbers";
        header("location:../Addcustomer.php");
    }
    else if(empty($garanter)){
        $_SESSION['message_post'] = "Insert Defaulter Garanters Name";
        header("location:../Addcustomer.php");
    }
    else{


    $query = "INSERT INTO `defaulter` (name,email,telephone,aadhar,loan_provider,loan_type,loan_amount,loan_duration,loan_garanter,address) values ('$name','$email',$contact,$aadhar,$loanprovider,'$loantype',$loanamount,'$loanduration','$garanter','$address')";
    $res = mysqli_query($connect,$query);

    if($res){
        $_SESSION['message_post'] = "<i class='fas fa-user-check'></i> Defaulter Added Successfully . . . ";
        header("location:../Addcustomer.php");
    }
    else{
        $_SESSION['message_post'] = "Defaulter did not insert";
        header("location:../Addcustomer.php");
    }
}
   
    

?>