<?php
session_start();
$user_id = $_SESSION['username'];
$veify = $_SESSION['verify_login_credential'];

if(!$veify){
  header('Location:http://localhost/bank%20project/fnferr.php');
  exit();
}
else if($veify){
  include "../../connection.php";
  $query = "SELECT * FROM `organizations` WHERE username='$user_id'";

    $res = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($res)){
        $db_random_var = $row['random_var'];
    }

    if($veify != $db_random_var){
      header('Location:http://localhost/bank%20project/fnferr.php');
      exit();
    }
}

$del_id=$_GET['del_id'];
include '../../connection.php';
$query = "DELETE FROM `defaulter` WHERE d_id='$del_id'";
$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
if($result == 1){
    $_SESSION['message_post'] = "<h3> <i class='far fa-trash-alt'></i> Defaulter Removed Succesfully ! </h3>";
    header("location:http://localhost/bank%20project/society/removecustomer.php");
}
?>