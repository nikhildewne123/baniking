<?php
      session_start();

      $user_id = $_SESSION['username'];
      $veify = $_SESSION['verify_login_credential'];

      if(!$veify){
        header('Location:http://localhost/bank%20project/fnferr.php');
        exit();
      }
      else if($veify){
        include "../connection.php";
        $query = "SELECT * FROM `organizations` WHERE username='$user_id'";
  
          $res = mysqli_query($connect,$query);
          while($row = mysqli_fetch_array($res)){
              $db_random_var = $row['random_var'];
          }

          if($veify != $db_random_var){
            header('Location:http://localhost/bank%20project/fnferr.php');
            exit();
          }
      }

      $aadhar = $_POST['adharnumber'];
      
      include('../connection.php');
      
      // check aadhar is present in database or not if not then redirect curor to prev page 
      $check = "SELECT aadhar FROM `defaulter` where aadhar='$aadhar'";
      $check_res = mysqli_query($connect,$check);
      if(mysqli_num_rows($check_res) < 1)
      {
        $_SESSION['message'] = "<a href='Bankpanel.php' style='color : white;'><i class='far fa-times-circle'></i></a> Aadhar Details not found or Wrong Inputs or field is Empty <a href='Bankpanel.php' style='color : white;'> <strong> Close </strong> </a>";
        header("location:Bankpanel.php");
      }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
        <style>
          body{
            background-color :#dfe6e0;
        }
            img{
                border-radius: 10px;
            }
            .list-bg{
                background-color : lightgrey;
                color : black;
            }
            .list-bg:hover{
                background-color : grey;
                color : white;
            }
            .admin-option a{
                text-decoration : none;
            }
        </style>
    </head>
    <body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand" href="#"> <i class='fas fa-balance-scale'></i>  Co-operative Society <sub>Dist : Hingoli</sub> </a>
           
    </nav>

            

                <main>
                <div class="container-fluid" style="padding : 10%; padding-top : 5%;">
                
                
                    <h1 class="mt-4" style="color : #d64949;"> Welcome , Bank id : <?php echo $_SESSION['bank_id']; ?></h1>



                    <?php

                      
                        include('../connection.php');

                        $user_id = $_SESSION['username'];
                        $query = "SELECT * FROM `organizations` WHERE username='$user_id'";

                      $res = mysqli_query($connect,$query);
                      while($row = mysqli_fetch_array($res)){
                          $name = $row['bname'];
                          $address = $row['adress'];
                          $contact = $row['contact'];
                          $email = $row['email'];
                          $logo = $row['logo'];
                          $directorphoto = $row['directorphoto'];
                      }
                    ?>

<!-- Organization Heading and logo and image section -->
            <div class="row jumbotron" style="padding : 20px; background-color : lightgrey;">
                            <div class="col-xl-2">
                            <img src="http://localhost/bank%20project/logoandimages/<?php echo $logo;?>"  width="100%" alt="">
                            </div>

                            <div class="col-xl-8" style="text-align : center;">
                          
                                <marquee behavior="" direction=""><h2>
                                <?php echo strtoupper($name); ?>
                                </h2></marquee>
                                </marquee>
                               <h5><?php echo $address; ?></h5>
                               <i class="fas fa-envelope"></i> Email id : <?php echo $email; ?> <br>
                               <i class="fas fa-phone-square"></i> Telephone : <?php echo $contact; ?><br>
                         
                            </div>

                            <div class="col-xl-2">
                            <img src="http://localhost/bank%20project/logoandimages/<?php echo $directorphoto;?>" width="100%" alt=""><br>
                               
                            

                            </div>
                    </div>


                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="../society/Bankpanel.php"> <i class="fas fa-home"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page"> <a href="removecustomer.php"><i class="fa fa-trash" aria-hidden="true"></i> Remove Customer</a> </li>
                                <li class="breadcrumb-item active" aria-current="page"> <a href="../society/Bankpanel.php"> <i class="fas fa-search-dollar"></i> Search Coustomer information</a> </li>
                         
                            </ol>
                     </nav>

                    <!--Success message -->

                    <span class = "errors"><?php
                                        if(!empty($_SESSION['message_post']))
                                        {

                                            ?>

                                        <div class="alert alert-success" role="alert">
                                       <?php echo $_SESSION['message_post'] ?>
                                        </div>

                                            <?php
                                        }
                                        
                                    ?></span>
                                <?php unset($_SESSION['message_post']); ?>

                                            

                       
                        

                       
                    <h3 style="background-color : white;">Defaulter Details</h3>
                    <div class="row jumbotron" style="background-color : lightgrey; padding : 2%;">

                    

                    <!-- add Customer form -->

                
                                        
                    <div class="col-xl-12">

                                        <!-- php script comes here -->

                                        <?php
                                          

                                            
                                            
                                            $query = "select * from `defaulter` where aadhar='$aadhar'";
                                            $res = mysqli_query($connect,$query);

                                            while($row = mysqli_fetch_array($res))
                                                {
                                                    $defaulter_name = $row['name'];
                                                    $defaulter_adress = $row['address'];
                                                    $defaulter_email = $row['email'];
                                                    $defaulter_contact = $row['telephone'];
                                                    $defaulter_aadhar = $row['aadhar'];
                                                }
                                           
                                          
                                         
                                           
                                        ?>


                                        <div class="deafulter-personel-details" style="background-color : #ffffff; padding:10px; border-radius : 5px;">
                                                <h4>Personel Information</h4>
                                             
                                            <table class="table table-striped table-bordered">
                                                <tr>
                                                    <td>
                                                        <h6>Name  </h6>
                                                    </td>
                                                    <td>
                                                        <h6><?php echo $defaulter_name;?></h6>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <h6>Address  </h6>
                                                    </td>
                                                    <td>
                                                        <h6><?php echo $defaulter_adress;?></h6>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <h6>Email Id  </h6>
                                                    </td>
                                                    <td>
                                                        <h6><?php echo $defaulter_email;?></h6>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <h6>Contact  </h6>
                                                    </td>
                                                    <td>
                                                        <h6><?php echo $defaulter_contact;?></h6>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <h6>Aadhar Number  </h6>
                                                    </td>
                                                    <td>
                                                        <h6><?php echo $defaulter_aadhar;?></h6>
                                                    </td>
                                                </tr>
                                            </table>

                                       </div>
                                        <hr>
                                        <div class="defaulter-loan-details"  style="background-color : #ffffff; padding:10px; border-radius : 5px;" >    

                                            <h4>Loan Taken From ( Loan Provider's Information )</h4>
                                        
                                        <br>
                                            
                                            <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Bank Name</th>
                                                    <th>loan Amount</th>
                                                    <th>Loan Duration</th>
                                                    <th>Garanter Name</th>

                                                </tr>
                                            </thead>

                                            <?php

                                                $aadhar = $_POST['adharnumber'];
                                                $query = "SELECT * from organizations,defaulter where organizations.id=defaulter.loan_provider and aadhar='$aadhar'";
                                                $result = mysqli_query($connect, $query) or die( mysqli_error($connection));
                                                while($row = mysqli_fetch_array($result))
                                                {
                                                    $loan_provider = $row['bname'];
                                                    $loan_amount = $row['loan_amount'];
                                                    $loan_duration = $row['loan_duration'];
                                                    $garanter = $row['loan_garanter'];
                                                   
                                                    ?>


                                                <tr>
                                                    <td><?php echo strtoupper($loan_provider);?></td>
                                                    <td><?php echo $loan_amount;?></td>
                                                    <td><?php echo $loan_duration;?></td>
                                                    <td><?php echo $garanter;?></td>
                                                </tr>
                                                   

                                                <?php 
                                                }
                                            ?>

                                            </table>


                                       </div>

                    </div>

                     
                    <!-- ends customer form -->
                   
                    </div>


                     
                     
                      
                    </div>
                </main>


                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Co-operative Society 2019</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>

          
                
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/datatables-demo.js"></script>
    </body>
</html>
