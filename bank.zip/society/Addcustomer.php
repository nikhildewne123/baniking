<?php
      session_start();

      $user_id = $_SESSION['username'];
      $veify = $_SESSION['verify_login_credential'];

      if(!$veify){
        header('Location:http://localhost/bank%20project/fnferr.php');
        exit();
      }
      else if($veify){
        include "../connection.php";
        $query = "SELECT * FROM `organizations` WHERE username='$user_id'";
  
          $res = mysqli_query($connect,$query);
          while($row = mysqli_fetch_array($res)){
              $db_random_var = $row['random_var'];
          }

          if($veify != $db_random_var){
            header('Location:http://localhost/bank%20project/fnferr.php');
            exit();
          }
      }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
        <style>
          body{
            background-color :#dfe6e0;
        }
            img{
                border-radius: 10px;
            }
            .list-bg{
                background-color : lightgrey;
                color : black;
            }
            .list-bg:hover{
                background-color : grey;
                color : white;
            }
            .admin-option a{
                text-decoration : none;
            }
        </style>
    </head>
    <body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand" href="#"> <i class='fas fa-balance-scale'></i>  Co-operative Society <sub>Dist : Hingoli</sub> </a>
           
    </nav>

            

                <main>
                <div class="container-fluid" style="padding : 10%; padding-top : 5%;">
                
                
                    <h1 class="mt-4" style="color : #d64949;">Welcome , Bank id : <?php echo $_SESSION['bank_id']; ?></h1>



                    <?php

                      
                        include('../connection.php');

                        $user_id = $_SESSION['username'];
                        $query = "SELECT * FROM `organizations` WHERE username='$user_id'";

                      $res = mysqli_query($connect,$query);
                      while($row = mysqli_fetch_array($res)){
                          $name = $row['bname'];
                          $address = $row['adress'];
                          $contact = $row['contact'];
                          $email = $row['email'];
                          $logo = $row['logo'];
                          $directorphoto = $row['directorphoto'];
                      }
                    ?>

<!-- Organization Heading and logo and image section -->
            <div class="row jumbotron" style="padding : 20px; background-color : lightgrey;">
                            <div class="col-xl-2">
                            <img src="http://localhost/bank%20project/logoandimages/<?php echo $logo;?>"  width="100%" alt="">
                            </div>

                            <div class="col-xl-8" style="text-align : center;">
                          
                                <h2>
                                <?php echo strtoupper($name); ?>
                                </h2>
                                </marquee>
                               <center> <h5><?php echo $address; ?></h5></center>
                               <i class="fas fa-envelope"></i> Email id : <?php echo $email; ?> <br>
                               <i class="fas fa-phone-square"></i> Telephone : <?php echo $contact; ?><br>
                         
                            </div>

                            <div class="col-xl-2">
                            <img src="http://localhost/bank%20project/logoandimages/<?php echo $directorphoto;?>" width="100%" alt=""><br>
                               
                            

                            </div>
                    </div>


                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="../society/Bankpanel.php"> <i class="fas fa-home"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page"> <a href=""><i class="fa fa-trash" aria-hidden="true"></i> Remove Customer</a> </li>
                                <li class="breadcrumb-item active" aria-current="page"> <a href="../society/Bankpanel.php"> <i class="fas fa-search-dollar"></i> Search Coustomer information</a> </li>
                         
                            </ol>
                     </nav>

                    <!--Success message -->

                    <span class = "errors"><?php
                                        if(!empty($_SESSION['message_post']))
                                        {

                                            ?>

                                        <div class="alert" style="background-color :red; color:#dfe6e0;" role="alert">
                                     <h3>  <?php echo $_SESSION['message_post']." !" ?>  </h3>
                                        </div>

                                            <?php
                                        }
                                        
                                    ?></span>
                                <?php unset($_SESSION['message_post']); ?>

                                            

                        <h2 class="btn-secondary" style="padding : 10px; border-radius : 5px;"> Add Defaulter</h2>
                        

                        <h2 style="padding : 5px;">Enter Customer Detail's</h2>

                    <div class="row jumbotron" style="background-color : lightgrey">

                    <!-- add Customer form -->

                    

                     
                        
                    <form action="scripts/insert.php" autocomplete="off" class="row" method="post">

                      
                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Customer <strong>  Name</strong></label>
                                    <input type="text" name="name" class="form-control" id="exampleFormControlInput1" placeholder="Enter Name of Costomer">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Customer <strong> @ Email </strong> </label>
                                    <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Example @ gmail . com">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Customer <strong> Telephone </strong> </label>
                                    <input type="number" name="contact" class="form-control" id="exampleFormControlInput1" placeholder="Enter Telephone">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Customer <strong> Aadhar Number </strong> </label>
                                    <input type="number" name="aadhar" class="form-control" id="exampleFormControlInput1" placeholder="Enter Aadhar number">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1"><strong> Type </strong> of Loan </label>
                                    <input type="text" name="loantype" class="form-control" id="exampleFormControlInput1" placeholder="Enter Type of loan">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Loan <strong> Amount </strong></label>
                                    <input type="number" name="loanamount" class="form-control" id="exampleFormControlInput1" placeholder="Enter loan amount">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Loan <strong> Duration </strong> </label>
                                    <input type="text" name="loanduration" class="form-control" id="exampleFormControlInput1" placeholder="Enter loan duration">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Customer's <strong> Garanter </strong> </label>
                                    <input type="text" name="loangaranter" class="form-control" id="exampleFormControlInput1" placeholder="Enter ganranters name">
                                  </div>
                            </div>


                         

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Customer <strong> Address </strong> </label>
                                    <textarea class="form-control" name="address" id="" cols="30" rows="5" placeholder="Enter Address"></textarea>
                                 </div>
                            </div>
                            
                         
                                        <!--
                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Upload Customer <strong> Image </strong>  </label>
                                    <input type="file" name="image" class="form-control" id="exampleFormControlInput1">
                                  </div>
                            </div>
                                    -->


                            <input type="hidden" name="bank_id" value="<?php echo $_SESSION['bank_id']; ?>">

                            <div class="col-xl-4">
                                <input type="submit" class="btn btn-danger" value="Add Defaulter">
                            </div>
                                    
                               
                                 
                            </form>

                    <!-- ends customer form -->
                   
                    </div>


                     
                     
                      
                    </div>
                </main>


                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Co-operative Society 2019</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>

          
                
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/datatables-demo.js"></script>
    </body>
</html>
