<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
<body>

<?php
// remove all session variables
session_unset(); 
// destroy the session 
session_destroy(); 
header("location:../../../../Bank Project/");
?>

</body>
</html>