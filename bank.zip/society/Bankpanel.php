<?php
      session_start();

      $user_id = $_SESSION['username'];
      $veify = $_SESSION['verify_login_credential'];

      if(!$veify){
        header('Location:http://localhost/bank%20project/fnferr.php');
        exit();
      }
      else if($veify){
        include "../connection.php";
        $query = "SELECT * FROM `organizations` WHERE username='$user_id'";
  
          $res = mysqli_query($connect,$query);
          while($row = mysqli_fetch_array($res)){
              $db_random_var = $row['random_var'];
          }

          if($veify != $db_random_var){
            header('Location:http://localhost/bank%20project/fnferr.php');
            exit();
          }
      }
      
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <style>
        body{
            background-color :#dfe6e0;
        }
            img{
                border-radius: 10px;
            }
            .list-bg{
                background-color : lightgrey;
                color : black;
            }
            .list-bg:hover{
                background-color : grey;
                color : white;
            }
            .admin-option a{
                text-decoration : none;
            }
            .blink_me {
                animation: blinker 0.2s linear infinite;
                }

            @keyframes blinker {
            50% {
                opacity: 0;
            }
            }
        </style>
    </head>
    <body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark" style="padding : 10px;">
            <a class="navbar-brand" href="#"><i class='fas fa-balance-scale'></i> Co-Operative Society <sub>Dist : Hingoli</sub> </a>
           
    </nav>

            

                <main>
                    <div class="container-fluid" style="padding : 10%; padding-top : 5%;">
                
                
                    <h1 class="mt-4 blink_me" style="color : #d64949;">Welcome , Bank id : <?php echo $_SESSION['bank_id']; ?> </h1>



                    <?php

                      
                        include('../connection.php');

                        $user_id = $_SESSION['username'];
                        $query = "SELECT * FROM `organizations` WHERE username='$user_id'";

                      $res = mysqli_query($connect,$query);
                      while($row = mysqli_fetch_array($res)){
                          $name = $row['bname'];
                          $address = $row['adress'];
                          $contact = $row['contact'];
                          $email = $row['email'];
                          $logo = $row['logo'];
                          $directorphoto = $row['directorphoto'];
                      }
                    ?>

<!-- Organization Heading and logo and image section -->
                    <div class="row jumbotron" style="padding : 20px; background-color : lightgrey;">
                            <div class="col-xl-2">
                           <img src="http://localhost/bank%20project/logoandimages/<?php echo $logo;?>"  width="100%" alt="">
                            </div>

                            <div class="col-xl-8" style="text-align : center;">
                           
                                <h2>
                             <marquee behavior="" direction="">   <?php echo strtoupper($name); ?> </marquee>
                                </h2>
                                </marquee>
                              <h5><?php echo strtoupper($address); ?></h5>
                               <i class="fas fa-envelope"></i> Email id : <?php echo $email; ?> <br>
                               <i class="fas fa-phone-square"></i> Telephone : <?php echo $contact; ?><br>
                         
                            </div>

                            <div class="col-xl-2">
                            <img src="http://localhost/bank%20project/logoandimages/<?php echo $directorphoto;?>" width="100%" alt=""><br>
                                <center><strong> Director </strong> </center>
                            

                            </div>
                    </div>

                        
        						

                        

                        <h2><i class='fas fa-thumbtack'></i> Defaulter Customer Information System</h2>
                        <hr class="my-4">

                        <span class = "errors"><?php
                                        if(!empty($_SESSION['message']))
                                        {
											?>
											


											<span class="btn-danger" style="padding : 10px;"><?php echo $_SESSION['message']; ?></span>
											
											<?php
                                        }
                                        
                                    ?></span>
                                <?php unset($_SESSION['message']); ?>


                    <div class="row jumbotron">

                   
                        

                        <div class="col-xl-4">

                            <ul class="list-group admin-option">
                               <a href="Addcustomer.php"> <li class="list-group-item list-bg"><i class="fa fa-user-plus" aria-hidden="true"></i> Add Defaulter</li></a>
                               <a href="removecustomer.php"> <li class="list-group-item list-bg"><i class="fa fa-trash" aria-hidden="true"></i>
                    Remove Defaulter</li></a>
                           <!--     <li class="list-group-item list-bg"><i class='fas fa-edit'></i>
                    Update Defaulter</li> -->
                            <a href="customers.php">  <li class="list-group-item list-bg"><i class="fa fa-users" aria-hidden="true"></i>
                    Defaulter Customers</li></a>
                               <a href="logout.php"> <li class="list-group-item list-bg"><i class="fas fa-sign-out-alt"></i>

                    log out</li></a>
                            </ul>

                        </div>
                    <!-- Search Section -->
                        <div class="col-xl-4" style="border:1px solid grey; padding : 10px; text-align:center;">
                       
                        <h4 style="text-align : center"><i class="fa fa-address-card" aria-hidden="true"></i> ENTER ADHAR CARD</h4>

                         <small><i class="fa fa-search" aria-hidden="true"></i> Search Customer Information</small>
                        <form action="searchresult.php" method="post"><br>
                            <input type="search" class="form-control " name="adharnumber" id="" placeholder="Enter Adhar Card Number"><br>
                            <input type="submit" class="btn-danger btn" value="Search Information">
                        </form>


                        </div>

                    <!--Search SEction ends here -->


                        <div class="col-xl-4">
                            <h5>* Important</h5>
                            <hr>
                            <ul class="list-group admin-option">
                             <!--  <a href="#"> <li class="list-group-item list-bg"><i class="fas fa-clipboard"></i>  Society Notice Board </del></li></a>-->
                                
                            <li class="list-group-item list-bg"><i class="fas fa-key"></i>
                            Update Password</del> </li>
                            <!--<li class="list-group-item list-bg"><i class='fas fa-edit'></i>
                            Post Notice </del></li>-->
                             
                            </ul>

                        </div>
                           

                      


                    </div>


                     
                     
                      
                    </div>
                </main>


                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Co-operative Society 2019</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>

          
                
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/datatables-demo.js"></script>
    </body>
</html>
