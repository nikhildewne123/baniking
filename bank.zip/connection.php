<?php

    $connect = mysqli_connect("localhost","root","","corporatesociety");
      
        if(!$connect){
            echo " connection failed " ;
        }

?>