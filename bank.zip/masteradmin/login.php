<?php

    session_start();
    include("../connection.php");
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    
        $query = "SELECT * FROM `master_login`";
        $result = mysqli_query($connect, $query) or die(mysqli_error($connect));
        if (mysqli_num_rows($result) > 0) {
            // output data of each row
            while($row = mysqli_fetch_array($result)) {
                //comparing email id
               
                if ($username == $row['username'] and $password == $row['password']){
                    //if email and password verifies then redirecting user to profile home page
                    $_SESSION['username'] = $row['username'];
                    header("location:masteradmin.php");
                }
                else{
                    header("location:index.php");
                }
            }
        }
      
?>