<?php
      session_start();

      if(!isset($_SESSION['username']))
      {
          
          header('Location:http://localhost/bank%20project/fnferr.php');
          exit();
      }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <link href="../../css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand" href="index.html">Co-operative Society Dist : Hingoli</a><button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#" style="float:right;"><i class="fas fa-bars"></i></button
            ><!-- Navbar Search-->
           
            <!-- Navbar-->
         
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="index.html"
                                ><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Add Organization</a >
                                <a class="nav-link" href="index.html"
                                ><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Update Organization</a >
                                <a class="nav-link" href="index.html"
                                ><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Remove Organization</a >
                                <a class="nav-link" href="index.html"
                                ><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Change Credential</a >
                                <a class="nav-link" href="../index.php"
                                ><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Log Out</a >
                           
                          
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        Master Admin
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        
                        <br>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Master Admin - Co-operative Society Hingoli</li>
                        </ol>
                        <h1 class="mt-4">Insert Organization</h1>
                        <hr>
                        
                        <form action="script/insert.php" class="row" method="post" enctype="multipart/form-data">
                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Organization Name</label>
                                    <input type="text" name="name" class="form-control" id="exampleFormControlInput1" placeholder="Enter Name of Organization">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Organization Email </label>
                                    <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Example @ gmail . com">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Organization Telephone </label>
                                    <input type="number" name="contact" class="form-control" id="exampleFormControlInput1" placeholder="Enter Telephone">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Organization Username </label>
                                    <input type="text" name="username" class="form-control" id="exampleFormControlInput1" placeholder="Enter Username">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Organization Password </label>
                                    <input type="text" name="password" class="form-control" id="exampleFormControlInput1" placeholder="Enter Password">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Organization Address </label>
                                    <textarea class="form-control" name="address" id="" cols="30" rows="5" placeholder="Enter Address"></textarea>
                                 </div>
                            </div>
                            
                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Upload Logo </label>
                                    <input type="file" name="file_logo" class="form-control" id="exampleFormControlInput1">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Upload Director photo  </label>
                                    <input type="file" name="file_dimage" class="form-control" id="exampleFormControlInput1">
                                  </div>
                            </div>

                            <div class="col-xl-4">
                                <input type="submit" class="btn btn-danger" value="Add Organization">
                            </div>
                                    
                               
                                 
                            </form>

                        
                     
                      
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2019</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/datatables-demo.js"></script>
    </body>
</html>
