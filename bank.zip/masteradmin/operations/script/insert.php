<?php

session_start();

if(!isset($_SESSION['username']))
{
    
    header('Location:http://localhost/bank%20project/fnferr.php');
    exit();
}

    include("../../../connection.php");

    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $address = $_POST['address'];

    $random = rand(100000,900000);

    $photo_name_logo = $_FILES["file_logo"]["name"];
    $photo_name_director = $_FILES["file_dimage"]["name"];


    $query = "INSERT INTO `organizations` (bname,adress,contact,email,username,password,logo,directorphoto,random_var) values ('$name','$address','$contact','$email','$username','$password','$photo_name_logo','$photo_name_director','$random')";
    $res = mysqli_query($connect,$query);
    if(!$res){
        header('../../masteradmin.php');
    }

    // logo upload script
    $target_dir = "../../../logoandimages/";
    $target_file = $target_dir . basename($_FILES["file_logo"]["name"]);
    $photo_name_logo = $_FILES["file_logo"]["name"];
    move_uploaded_file($_FILES["file_logo"]["tmp_name"], $target_file);
    // logo upload script ends here . . . .


    // director image upload script
    $target_dir = "../../../logoandimages/";
    $target_file = $target_dir . basename($_FILES["file_dimage"]["name"]);
    $photo_name_director = $_FILES["file_dimage"]["name"];
    move_uploaded_file($_FILES["file_dimage"]["tmp_name"], $target_file);
    // director image upload script ends here . . . .

    
    



    echo "inserted successfully ! ";
    echo "<a href='masteradmin.php'>Go Banck</a>"

?>